﻿//====================================================================================================
//The Free Edition of C# to Python Converter limits conversion output to 100 lines per file.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-csharp-to-python.html
//====================================================================================================

class LoadinScreen: #this class replaces the original namespace 'LoadinScreen'
    class Form1(Form):
        def __init__(self):
            #instance fields found by C# to Python Converter:
            self._components = None
            self._pictureBox1 = None
            self._label1 = None
            self._label2 = None
            self._pictureBox2 = None
            self._pictureBox3 = None
            self._panel1 = None
            self._panel2 = None
            self._button1 = None
            self._label3 = None
            self._label4 = None
            self._txtUserName = None
            self._txtpassword = None

            self._InitializeComponent()

        def _button1_Click(self, sender, e):
            if self._txtUserName.Text=="CPE106" and self._txtpassword.Text=="123456":
                (Form2()).Show()
                self.Hide()
            else:
                MessageBox.Show("Username and Password Does not Match")
                self._txtUserName.Clear()
                self._txtpassword.Clear()
                self._txtUserName.Focus()

        def _label3_Click(self, sender, e):
            self._txtUserName.Clear()
            self._txtpassword.Clear()
            self._txtUserName.Focus()

        def _label4_Click(self, sender, e):
            Application.Exit()

        def _Form1_Load(self, sender, e):

            pass


        #/ <summary>
        #/ Required designer variable.
        #/ </summary>

        #/ <summary>
        #/ Clean up any resources being used.
        #/ </summary>
        #/ <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        def Dispose(self, disposing):
            if disposing and (components is not None):
                self._components.Dispose()
            super().Dispose(disposing)

#C# TO PYTHON CONVERTER TODO TASK: There is no preprocessor in Python:
        ##region Windows Form Designer generated code

        #/ <summary>
        #/ Required method for Designer support - do not modify
        #/ the contents of this method with the code editor.
        #/ </summary>
        def _InitializeComponent(self):
            self._label1 = System.Windows.Forms.Label()
            self._label2 = System.Windows.Forms.Label()
            self._pictureBox3 = System.Windows.Forms.PictureBox()
            self._pictureBox2 = System.Windows.Forms.PictureBox()
            self._pictureBox1 = System.Windows.Forms.PictureBox()
            self._panel1 = System.Windows.Forms.Panel()
            self._panel2 = System.Windows.Forms.Panel()
            self._button1 = System.Windows.Forms.Button()
            self._label3 = System.Windows.Forms.Label()
            self._label4 = System.Windows.Forms.Label()
            self._txtUserName = System.Windows.Forms.TextBox()
            self._txtpassword = System.Windows.Forms.TextBox()
            ((self._pictureBox3)).BeginInit()
            ((self._pictureBox2)).BeginInit()
            ((self._pictureBox1)).BeginInit()
            self.SuspendLayout()
            # 
            # label1
            # 
            self._label1.AutoSize = True
            self._label1.Font = System.Drawing.Font("Microsoft YaHei", 14.25, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, (int((0))))
            self._label1.ForeColor = System.Drawing.Color.Purple
            self._label1.Location = System.Drawing.Point(66, 147)
            self._label1.Name = "label1"
            self._label1.Size = System.Drawing.Size(155, 26)
            self._label1.TabIndex = 1
            self._label1.Text = "Fitness Tracker"
            # 
            # label2
            # 
            self._label2.AutoSize = True
            self._label2.ForeColor = System.Drawing.Color.Purple
            self._label2.Location = System.Drawing.Point(120, 173)
            self._label2.Name = "label2"
            self._label2.Size = System.Drawing.Size(45, 13)
            self._label2.TabIndex = 1
            self._label2.Text = "Group 4"
            # 
            # pictureBox3
            # 
            self._pictureBox3.Image = global_::LoadinScreen.Properties.Resources.get_lc()
            self._pictureBox3.Location = System.Drawing.Point(22, 288)
            self._pictureBox3.Name = "pictureBox3"
            self._pictureBox3.Size = System.Drawing.Size(25, 25)
            self._pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
            self._pictureBox3.TabIndex = 2
            self._pictureBox3.TabStop = False
            # 
            # pictureBox2
            # 
            self._pictureBox2.Image = global_::LoadinScreen.Properties.Resources.get_pw()
            self._pictureBox2.Location = System.Drawing.Point(22, 246)
            self._pictureBox2.Name = "pictureBox2"
            self._pictureBox2.Size = System.Drawing.Size(25, 25)
            self._pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
            self._pictureBox2.TabIndex = 2
            self._pictureBox2.TabStop = False
            # 
            # pictureBox1
            # 
            self._pictureBox1.Image = global_::LoadinScreen.Properties.Resources.get_gym()
            self._pictureBox1.Location = System.Drawing.Point(99, 68)
            self._pictureBox1.Name = "pictureBox1"
            self._pictureBox1.Size = System.Drawing.Size(87, 71)
            self._pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            self._pictureBox1.TabIndex = 0
            self._pictureBox1.TabStop = False
            # 
            # panel1
            # 
            self._panel1.BackColor = System.Drawing.Color.Purple
            self._panel1.Location = System.Drawing.Point(22, 270)
            self._panel1.Name = "panel1"
            self._panel1.Size = System.Drawing.Size(236, 1)
            self._panel1.TabIndex = 3
            # 
            # panel2
            # 
            self._panel2.BackColor = System.Drawing.Color.Purple
            self._panel2.Location = System.Drawing.Point(22, 312)
            self._panel2.Name = "panel2"
            self._panel2.Size = System.Drawing.Size(236, 1)

//====================================================================================================
//End of the allowed output for the Free Edition of C# to Python Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-csharp-to-python.html
//====================================================================================================
