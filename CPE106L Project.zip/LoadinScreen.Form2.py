﻿//====================================================================================================
//The Free Edition of C# to Python Converter limits conversion output to 100 lines per file.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-csharp-to-python.html
//====================================================================================================

class LoadinScreen: #this class replaces the original namespace 'LoadinScreen'
    class Form2(Form):

#C# TO PYTHON CONVERTER TODO TASK: C# attributes do not have Python equivalents:
#ORIGINAL LINE: [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")] private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);
#C# TO PYTHON CONVERTER TODO TASK: Unmanaged dll access must be converted manually:
#        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse)
        def __init__(self):
            #instance fields found by C# to Python Converter:
            self._components = None
            self._panel1 = None
            self._btnDashbord = None
            self._panel2 = None
            self._label2 = None
            self._label1 = None
            self._pictureBox1 = None
            self._pictureBox6 = None
            self._pictureBox5 = None
            self._pictureBox4 = None
            self._pictureBox3 = None
            self._pictureBox2 = None
            self._btnContactUs = None
            self._btnsettings = None
            self._btnCalendar = None
            self._btnAnalytics = None
            self._pnlNav = None
            self._label3 = None
            self._textBox1 = None
            self._button1 = None
            self._panel3 = None
            self._pictureBox7 = None
            self._label5 = None
            self._label6 = None
            self._label4 = None
            self._panel4 = None
            self._pictureBox8 = None
            self._label7 = None
            self._label8 = None
            self._label9 = None
            self._panel5 = None
            self._pictureBox9 = None
            self._label10 = None
            self._label11 = None
            self._label12 = None
            self._panel6 = None
            self._pictureBox10 = None
            self._label13 = None
            self._label14 = None
            self._label15 = None
            self._panel7 = None
            self._pictureBox11 = None
            self._label16 = None
            self._label17 = None
            self._label18 = None
            self._panel8 = None
            self._pictureBox12 = None
            self._label19 = None
            self._label20 = None
            self._label21 = None
            self._label22 = None
            self._label23 = None
            self._panel9 = None
            self._pictureBox13 = None
            self._label26 = None
            self._panel10 = None
            self._pictureBox14 = None
            self._label24 = None
            self._pictureBox15 = None
            self._label25 = None

            self._InitializeComponent()
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25))
            self._pnlNav.Height = self._btnDashbord.Height
            self._pnlNav.Top = self._btnDashbord.Top
            self._pnlNav.Left = self._btnDashbord.Left
            self._btnDashbord.BackColor = Color.WhiteSmoke

        def _Form2_Load(self, sender, e):

            pass

        def _btnDashbord_Click(self, sender, e):
            self._pnlNav.Height = self._btnDashbord.Height
            self._pnlNav.Top = self._btnDashbord.Top
            self._pnlNav.Left = self._btnDashbord.Left
            self._btnDashbord.BackColor = Color.WhiteSmoke

        def _btnAnalytics_Click(self, sender, e):
            self._pnlNav.Height = self._btnAnalytics.Height
            self._pnlNav.Top = self._btnAnalytics.Top
            self._btnAnalytics.BackColor = Color.WhiteSmoke

        def _btnCalendar_Click(self, sender, e):
            self._pnlNav.Height = self._btnCalendar.Height
            self._pnlNav.Top = self._btnCalendar.Top
            self._btnCalendar.BackColor = Color.WhiteSmoke

        def _btnContactUs_Click(self, sender, e):
            self._pnlNav.Height = self._btnContactUs.Height
            self._pnlNav.Top = self._btnContactUs.Top
            self._btnContactUs.BackColor = Color.WhiteSmoke

        def _btnsettings_Click(self, sender, e):
            self._pnlNav.Height = self._btnsettings.Height
            self._pnlNav.Top = self._btnsettings.Top
            self._btnsettings.BackColor = Color.WhiteSmoke

        def _btnDashbord_Leave(self, sender, e):
            self._btnDashbord.BackColor = Color.WhiteSmoke

        def _btnAnalytics_Leave(self, sender, e):
            self._btnAnalytics.BackColor = Color.WhiteSmoke

        def _btnCalendar_Leave(self, sender, e):
            self._btnCalendar.BackColor = Color.WhiteSmoke

        def _btnContactUs_Leave(self, sender, e):
            self._btnContactUs.BackColor = Color.WhiteSmoke


//====================================================================================================
//End of the allowed output for the Free Edition of C# to Python Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-csharp-to-python.html
//====================================================================================================
