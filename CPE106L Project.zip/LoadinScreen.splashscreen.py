﻿class LoadinScreen: #this class replaces the original namespace 'LoadinScreen'
    class splashscreen(Form):
        def __init__(self):
            #instance fields found by C# to Python Converter:
            self._components = None
            self._pictureBox1 = None
            self._progressBar1 = None
            self._timer1 = None
            self._textBox1 = None

            self._InitializeComponent()

        def _timer1_Tick(self, sender, e):
            self._timer1.Enabled = True
            self._progressBar1.Increment(2)
            if self._progressBar1.Value == 100:
                self._timer1.Enabled = False
                form = Form1()
                form.Show()
                self.Hide()



        #/ <summary>
        #/ Required designer variable.
        #/ </summary>

        #/ <summary>
        #/ Clean up any resources being used.
        #/ </summary>
        #/ <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        def Dispose(self, disposing):
            if disposing and (components is not None):
                self._components.Dispose()
            super().Dispose(disposing)

#C# TO PYTHON CONVERTER TODO TASK: There is no preprocessor in Python:
        ##region Windows Form Designer generated code

        #/ <summary>
        #/ Required method for Designer support - do not modify
        #/ the contents of this method with the code editor.
        #/ </summary>
        def _InitializeComponent(self):
            self._components = System.ComponentModel.Container()
            self._pictureBox1 = System.Windows.Forms.PictureBox()
            self._progressBar1 = System.Windows.Forms.ProgressBar()
            self._timer1 = System.Windows.Forms.Timer(self._components)
            self._textBox1 = System.Windows.Forms.TextBox()
            ((self._pictureBox1)).BeginInit()
            self.SuspendLayout()
            # 
            # pictureBox1
            # 
            self._pictureBox1.BackColor = System.Drawing.Color.Black
            self._pictureBox1.Image = global_::LoadinScreen.Properties.Resources.get_music()
            self._pictureBox1.Location = System.Drawing.Point(185, 85)
            self._pictureBox1.Name = "pictureBox1"
            self._pictureBox1.Size = System.Drawing.Size(39, 34)
            self._pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
            self._pictureBox1.TabIndex = 0
            self._pictureBox1.TabStop = False
            # 
            # progressBar1
            # 
            self._progressBar1.Location = System.Drawing.Point(12, 231)
            self._progressBar1.Name = "progressBar1"
            self._progressBar1.Size = System.Drawing.Size(350, 6)
            self._progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous
            self._progressBar1.TabIndex = 1
            # 
            # timer1
            # 
            self._timer1.Enabled = True
#C# TO PYTHON CONVERTER TODO TASK: Python has no equivalent to C#-style event wireups:
            self.timer1.Tick += new System.EventHandler(self.timer1_Tick)
            # 
            # textBox1
            # 
            self._textBox1.BackColor = System.Drawing.Color.Black
            self._textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None_
            self._textBox1.Font = System.Drawing.Font("Microsoft Uighur", 9.75, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, (int((0))))
            self._textBox1.ForeColor = System.Drawing.Color.White
            self._textBox1.Location = System.Drawing.Point(258, 210)
            self._textBox1.Name = "textBox1"
            self._textBox1.Size = System.Drawing.Size(100, 15)
            self._textBox1.TabIndex = 2
            self._textBox1.Text = "Copyrights  © Group 4"
            # 
            # splashscreen
            # 
            self.AutoScaleDimensions = System.Drawing.SizeF(6, 13)
            self.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            self.BackgroundImage = global_::LoadinScreen.Properties.Resources.get_wo()
            self.ClientSize = System.Drawing.Size(370, 244)
            self.Controls.Add(self._textBox1)
            self.Controls.Add(self._progressBar1)
            self.Controls.Add(self._pictureBox1)
            self.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None_
            self.Name = "splashscreen"
            self.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            self.Text = "splashscreen"
            ((self._pictureBox1)).EndInit()
            self.ResumeLayout(False)
            self.PerformLayout()


#C# TO PYTHON CONVERTER TODO TASK: There is no preprocessor in Python:
        ##endregion
