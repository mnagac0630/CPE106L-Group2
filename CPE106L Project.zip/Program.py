﻿class LoadinScreen: #this class replaces the original namespace 'LoadinScreen'
    class Program:
        #/ <summary>
        #/ The main entry point for the application.
        #/ </summary>
#C# TO PYTHON CONVERTER TODO TASK: C# attributes do not have Python equivalents:
#ORIGINAL LINE: [STAThread] static void Main()
        @staticmethod
        def Main():
            #Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(splashscreen())
