﻿def main():
    LoadinScreen.Program.Main()

if __name__ == "__main__":
    main()

